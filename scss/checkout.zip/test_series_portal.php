<div class="col-lg-12">
    <div class="row">
        <div class="col-lg-2">

        </div>
        <div class="col-lg-8">

        <!-- upload google form -->

        </div>
        <div class="col-lg-2">

        </div>
    </div>
</div>
