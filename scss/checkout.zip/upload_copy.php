<?php



?>

<div class="col-lg-12">
    <div class="row">
        <div class="col-lg-2">

        </div>
        <div class="col-lg-8">

        <!-- put google form here -->

        </div>
        <div class="col-lg-2">

        </div>
    </div>
</div>
